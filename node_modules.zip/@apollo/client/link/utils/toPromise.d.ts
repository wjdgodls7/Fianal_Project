/// <reference types="zen-observable" />
import { Observable } from '../../utilities';
export declare function toPromise<R>(observable: Observable<R>): Promise<R>;
//# sourceMappingURL=toPromise.d.ts.map