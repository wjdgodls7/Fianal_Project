/// <reference types="zen-observable" />
import { Observable } from '../../utilities';
export declare function fromError<T>(errorValue: any): Observable<T>;
//# sourceMappingURL=fromError.d.ts.map