import { GraphQLRequest, Operation } from '../core';
export declare function createOperation(starting: any, operation: GraphQLRequest): Operation;
//# sourceMappingURL=createOperation.d.ts.map