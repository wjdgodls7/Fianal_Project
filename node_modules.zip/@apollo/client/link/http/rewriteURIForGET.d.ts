import { Body } from './selectHttpOptionsAndBody';
export declare function rewriteURIForGET(chosenURI: string, body: Body): {
    parseError: any;
    newURI?: undefined;
} | {
    newURI: string;
    parseError?: undefined;
};
//# sourceMappingURL=rewriteURIForGET.d.ts.map