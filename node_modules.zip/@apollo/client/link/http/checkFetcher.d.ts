export declare const checkFetcher: (fetcher: WindowOrWorkerGlobalScope['fetch'] | undefined) => void;
//# sourceMappingURL=checkFetcher.d.ts.map