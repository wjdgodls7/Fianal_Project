import { ApolloLink } from './ApolloLink';
export declare const execute: typeof ApolloLink.execute;
//# sourceMappingURL=execute.d.ts.map