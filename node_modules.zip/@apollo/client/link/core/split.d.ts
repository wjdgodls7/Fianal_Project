import { ApolloLink } from './ApolloLink';
export declare const split: typeof ApolloLink.split;
//# sourceMappingURL=split.d.ts.map