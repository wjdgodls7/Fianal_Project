import { ApolloLink } from './ApolloLink';
export declare const from: typeof ApolloLink.from;
//# sourceMappingURL=from.d.ts.map