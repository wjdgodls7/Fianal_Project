import { ApolloLink } from "./ApolloLink.js";
export var empty = ApolloLink.empty;
//# sourceMappingURL=empty.js.map