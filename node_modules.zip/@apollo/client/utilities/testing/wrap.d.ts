declare const _default: <TArgs extends any[], TResult>(reject: (reason: any) => any, cb: (...args: TArgs) => TResult) => (...args: TArgs) => TResult | undefined;
export default _default;
export declare function withError(func: Function, regex: RegExp): any;
//# sourceMappingURL=wrap.d.ts.map