export function stripSymbols(data) {
    return JSON.parse(JSON.stringify(data));
}
//# sourceMappingURL=stripSymbols.js.map