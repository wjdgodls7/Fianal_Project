export declare function stripSymbols<T>(data: T): T;
//# sourceMappingURL=stripSymbols.d.ts.map