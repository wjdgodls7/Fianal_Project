import { QueryManager } from '../../../core/QueryManager';
import { MockedResponse } from './mockLink';
declare const _default: (reject: (reason: any) => any, ...mockedResponses: MockedResponse[]) => QueryManager<import("../../..").NormalizedCacheObject>;
export default _default;
//# sourceMappingURL=mockQueryManager.d.ts.map