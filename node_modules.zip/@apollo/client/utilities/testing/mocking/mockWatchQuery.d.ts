import { MockedResponse } from './mockLink';
import { ObservableQuery } from '../../../core/ObservableQuery';
declare const _default: (reject: (reason: any) => any, ...mockedResponses: MockedResponse[]) => ObservableQuery<any>;
export default _default;
//# sourceMappingURL=mockWatchQuery.d.ts.map