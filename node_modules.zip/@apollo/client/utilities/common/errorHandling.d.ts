import { ExecutionResult } from 'graphql';
export declare function graphQLResultHasError(result: ExecutionResult): boolean;
//# sourceMappingURL=errorHandling.d.ts.map