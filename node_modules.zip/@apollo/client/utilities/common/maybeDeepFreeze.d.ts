export declare function maybeDeepFreeze<T>(obj: T): T;
//# sourceMappingURL=maybeDeepFreeze.d.ts.map