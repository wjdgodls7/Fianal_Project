export declare function isNonEmptyArray<T>(value?: ArrayLike<T>): value is Array<T>;
//# sourceMappingURL=arrays.d.ts.map