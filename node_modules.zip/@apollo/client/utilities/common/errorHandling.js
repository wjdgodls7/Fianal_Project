export function graphQLResultHasError(result) {
    return (result.errors && result.errors.length > 0) || false;
}
//# sourceMappingURL=errorHandling.js.map