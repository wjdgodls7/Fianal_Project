export declare function cloneDeep<T>(value: T): T;
//# sourceMappingURL=cloneDeep.d.ts.map