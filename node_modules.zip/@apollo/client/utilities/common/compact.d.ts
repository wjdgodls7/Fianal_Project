import { TupleToIntersection } from './mergeDeep';
export declare function compact<TArgs extends any[]>(...objects: TArgs): TupleToIntersection<TArgs>;
//# sourceMappingURL=compact.d.ts.map