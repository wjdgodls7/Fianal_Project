export declare const version = "local";
//# sourceMappingURL=version.d.ts.map