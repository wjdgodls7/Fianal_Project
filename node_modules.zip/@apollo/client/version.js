export var version = '3.3.6';
//# sourceMappingURL=version.js.map