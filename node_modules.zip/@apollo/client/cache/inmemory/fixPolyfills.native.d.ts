export {};
//# sourceMappingURL=fixPolyfills.native.d.ts.map