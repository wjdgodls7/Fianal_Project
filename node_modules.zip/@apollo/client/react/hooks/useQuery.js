import { useBaseQuery } from "./utils/useBaseQuery.js";
export function useQuery(query, options) {
    return useBaseQuery(query, options, false);
}
//# sourceMappingURL=useQuery.js.map