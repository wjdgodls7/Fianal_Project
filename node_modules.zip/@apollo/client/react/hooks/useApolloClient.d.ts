import { ApolloClient } from '../../core';
export declare function useApolloClient(): ApolloClient<object>;
//# sourceMappingURL=useApolloClient.d.ts.map