import { ReactiveVar } from '../../core';
export declare function useReactiveVar<T>(rv: ReactiveVar<T>): T;
//# sourceMappingURL=useReactiveVar.d.ts.map