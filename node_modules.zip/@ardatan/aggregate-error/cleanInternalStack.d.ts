export declare const cleanInternalStack: (stack: string) => string;
